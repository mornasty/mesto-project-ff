import '../pages/index.css';
import './cards';
import './card';
import './modal';